# Configuration file for Maqsadly Marathon Bot

BOT_TOKEN = '7898776361:AAEvl6HbhS21nWLP2h1_Tr_OTZZ-nK_967g'
ADMIN_IDS = [440036522]  # Replace with actual admin Telegram user IDs
CHANNEL_IDS = {
    -1002894881078: "Maqsadly Edu",
    -1001281411811: "Eldor Khamraev",
    -1001803075478: "Ozodiiy",
    -1002155188744: "Garbiz Official",
    -1002277135189: "Shoks927",
    -1001661528628: "Notasill",
    -1002245418335: "Jamshidbek Izzatulloh | Blog",
    -1001548867673: "levsha",
    -1001717798983: "Parviz's path | SAT 1600",
    -1001825051597: "Abdulazizziy",
    -1001835327505: "Bobirjon's Thoughts",
    # Add more as needed
}
PRIVATE_GROUP_ID = -1002830897570  # Updated to your channel ID 