GREETING_MESSAGE = 'Hello, {name}!\n\nWelcome to the Maqsadly 11-day marathon!'

SUBSCRIPTION_MESSAGE = 'Please subscribe to the following 11 channels:\n\n{links}\n\nAfter subscribing, press the "Check" button below.' 